<?php
// Frontend - Pagina principal
// Mostra les visites (redis) i els articles (mysql)

// agafem les variables d'entorn
$mysqlHost = getenv('MYSQL_HOST') ?: 'mysql';
$mysqlDb   = getenv('MYSQL_DATABASE') ?: 'projecte_final';
$mysqlUser = getenv('MYSQL_USER') ?: 'project_user';
$mysqlPass = getenv('MYSQL_PASSWORD') ?: 'project_pass';
$redisHost = getenv('REDIS_HOST') ?: 'redis';

$visites = 0;
$articles = [];
$error = null;

// connectem amb redis i incrementem el comptador
try {
    $redis = new Redis();
    $redis->connect($redisHost, 6379);
    $visites = $redis->incr('page_views_frontend');
} catch (Exception $e) {
    error_log("Redis error: " . $e->getMessage());
    $visites = 0;
}

// agafem els ultims 5 articles de mysql
try {
    $dsn = "mysql:host={$mysqlHost};dbname={$mysqlDb};charset=utf8mb4";
    $pdo = new PDO($dsn, $mysqlUser, $mysqlPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    $stmt = $pdo->query("
        SELECT a.title, a.content, a.published_at, u.username
        FROM articles a
        JOIN users u ON a.user_id = u.id
        ORDER BY a.published_at DESC
        LIMIT 5
    ");
    $articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("MySQL error: " . $e->getMessage());
    $error = "No s'ha pogut connectar amb la base de dades.";
}
?>
<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Projecte UF2 ASIX2 - Docker Compose">
    <title>Projecte UF2 - frontend.local</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <header>
        <h1>🚀 Projecte UF2 – frontend.local</h1>
        <p class="subtitle">Integració Docker amb Apache, MySQL, Redis i phpMyAdmin</p>
    </header>

    <main>
        <!-- comptador de visites -->
        <section class="card">
            <h2>📊 Estadístiques</h2>
            <p><strong>Visites a la pàgina:</strong> <span id="visit-count"><?php echo htmlspecialchars($visites); ?></span></p>
        </section>

        <!-- articles -->
        <section class="card">
            <h2>📰 Últims 5 articles</h2>
            <?php if ($error): ?>
                <p class="error"><?php echo htmlspecialchars($error); ?></p>
            <?php elseif (empty($articles)): ?>
                <p>No hi ha articles disponibles.</p>
            <?php else: ?>
                <ul class="articles">
                    <?php foreach ($articles as $article): ?>
                        <li>
                            <h3><?php echo htmlspecialchars($article['title']); ?></h3>
                            <small>
                                Per <strong><?php echo htmlspecialchars($article['username']); ?></strong>
                                · <?php echo htmlspecialchars($article['published_at']); ?>
                            </small>
                            <p><?php echo nl2br(htmlspecialchars($article['content'])); ?></p>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>

        <!-- formulari per crear articles -->
        <section class="card">
            <h2>✍️ Crear nou article</h2>
            <form id="article-form">
                <div class="form-group">
                    <label for="title">Títol:</label>
                    <input type="text" id="title" name="title" required placeholder="Escriu el títol de l'article">
                </div>
                <div class="form-group">
                    <label for="content">Contingut:</label>
                    <textarea id="content" name="content" rows="4" required placeholder="Escriu el contingut de l'article"></textarea>
                </div>
                <button type="submit">📤 Publicar article</button>
                <p id="form-message" class="message"></p>
            </form>
        </section>
    </main>

    <footer>
        <p>Projecte UF2 ASIX2 · Alex Pica · 2024</p>
    </footer>

    <script src="/assets/js/app.js"></script>
</body>
</html>
