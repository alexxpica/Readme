<?php
// API REST - api.local
// Endpoints que he creat:
// - GET  /api/articles  -> torna tots els articles
// - POST /api/articles  -> crea un article nou
// - GET  /api/stats     -> estadistiques

header('Content-Type: application/json; charset=utf-8');

// variables d'entorn
$mysqlHost = getenv('MYSQL_HOST') ?: 'mysql';
$mysqlDb   = getenv('MYSQL_DATABASE') ?: 'projecte_final';
$mysqlUser = getenv('MYSQL_USER') ?: 'project_user';
$mysqlPass = getenv('MYSQL_PASSWORD') ?: 'project_pass';
$redisHost = getenv('REDIS_HOST') ?: 'redis';

// agafem el metode i la ruta
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$uri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($uri, PHP_URL_PATH);

// per les peticions OPTIONS (cors)
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// funcio per connectar amb mysql
function getDB() {
    global $mysqlHost, $mysqlDb, $mysqlUser, $mysqlPass;
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host={$mysqlHost};dbname={$mysqlDb};charset=utf8mb4";
        $pdo = new PDO($dsn, $mysqlUser, $mysqlPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

// funcio per connectar amb redis
function getRedis() {
    global $redisHost;
    static $redis = null;
    if ($redis === null) {
        $redis = new Redis();
        $redis->connect($redisHost, 6379);
    }
    return $redis;
}

// funcio helper per retornar json
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// funcio per retornar errors
function errorResponse($message, $status = 400) {
    jsonResponse(['error' => $message], $status);
}

// aqui comença el routing
try {
    // GET /api/articles - torna tots els articles
    if ($method === 'GET' && preg_match('#^/api/articles/?$#', $path)) {
        $pdo = getDB();
        $stmt = $pdo->query("
            SELECT a.id, a.title, a.content, a.published_at, u.username
            FROM articles a
            JOIN users u ON a.user_id = u.id
            ORDER BY a.published_at DESC
        ");
        $articles = $stmt->fetchAll();
        jsonResponse(['status' => 'ok', 'data' => $articles]);
    }

    // POST /api/articles - crea un article
    elseif ($method === 'POST' && preg_match('#^/api/articles/?$#', $path)) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || empty($input['title']) || empty($input['content'])) {
            errorResponse('Camps obligatoris: title, content');
        }
        
        $userId = isset($input['user_id']) ? (int)$input['user_id'] : 1;
        $title = trim($input['title']);
        $content = trim($input['content']);
        
        $pdo = getDB();
        $stmt = $pdo->prepare("
            INSERT INTO articles (user_id, title, content)
            VALUES (:user_id, :title, :content)
        ");
        $stmt->execute([
            ':user_id' => $userId,
            ':title' => $title,
            ':content' => $content,
        ]);
        
        $newId = $pdo->lastInsertId();
        jsonResponse([
            'status' => 'ok',
            'message' => 'Article creat correctament',
            'id' => $newId
        ], 201);
    }

    // GET /api/stats - estadistiques
    elseif ($method === 'GET' && preg_match('#^/api/stats/?$#', $path)) {
        $pdo = getDB();
        $redis = getRedis();
        
        $visites = (int) $redis->get('page_views_frontend') ?: 0;
        
        $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $articleCount = $pdo->query("SELECT COUNT(*) FROM articles")->fetchColumn();
        
        jsonResponse([
            'status' => 'ok',
            'stats' => [
                'visites' => $visites,
                'usuaris' => (int) $userCount,
                'articles' => (int) $articleCount,
            ]
        ]);
    }

    // GET / - info de l'api
    elseif ($method === 'GET' && ($path === '/' || $path === '')) {
        jsonResponse([
            'status' => 'ok',
            'message' => 'API del Projecte UF2',
            'version' => '1.0',
            'endpoints' => [
                'GET /api/articles' => 'Llista tots els articles',
                'POST /api/articles' => 'Crea un nou article',
                'GET /api/stats' => 'Estadístiques del sistema'
            ]
        ]);
    }

    // si no troba res, 404
    else {
        errorResponse('Endpoint no trobat', 404);
    }

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    errorResponse('Error de base de dades', 500);
} catch (RedisException $e) {
    error_log("Redis error: " . $e->getMessage());
    errorResponse('Error de cache', 500);
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    errorResponse('Error intern del servidor', 500);
}
