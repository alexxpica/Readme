-- Script per crear la base de dades

-- creem la bd si no existeix
CREATE DATABASE IF NOT EXISTS projecte_final
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE projecte_final;

-- taula d'usuaris
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- taula d'articles (amb fk a users)
CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_articles_user
      FOREIGN KEY (user_id) REFERENCES users(id)
      ON DELETE CASCADE
);

-- dades de prova
INSERT INTO users (username, email) VALUES
  ('alex', 'alex@example.com'),
  ('admin', 'admin@example.com');

INSERT INTO articles (user_id, title, content) VALUES
  (1, 'Primer article', 'Aquest es el primer article de prova.'),
  (1, 'Segon article', 'Mes contingut de prova per al projecte.'),
  (2, 'Article admin', 'Article creat per usuari alex pica castro.');
